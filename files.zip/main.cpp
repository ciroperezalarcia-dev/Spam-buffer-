#include <Geode/Geode.hpp>
#include <Geode/modify/PlayerObject.hpp>

using namespace geode::prelude;

class $modify(SpamPlayer, PlayerObject) {
    struct Fields {
        bool userHolding = false;  // el jugador mantiene el click
        bool spamDown = false;     // estado actual simulado (apretado / suelto)
        float timer = 0.f;
    };

    bool active() {
        return Mod::get()->getSettingValue<bool>("enabled")
            && PlayLayer::get() != nullptr;
    }

    // Esto se ejecuta cuando el JUGADOR aprieta (las llamadas internas
    // de abajo usan PlayerObject:: directamente y no pasan por acá).
    bool pushButton(PlayerButton btn) {
        if (btn == PlayerButton::Jump && active()) {
            m_fields->userHolding = true;
            m_fields->spamDown = true;
            m_fields->timer = 0.f;
        }
        return PlayerObject::pushButton(btn);
    }

    bool releaseButton(PlayerButton btn) {
        if (btn == PlayerButton::Jump) {
            m_fields->userHolding = false;
            // Si el spam ya lo había soltado, no soltamos dos veces.
            if (active() && !m_fields->spamDown) return false;
            m_fields->spamDown = false;
        }
        return PlayerObject::releaseButton(btn);
    }

    void update(float dt) {
        PlayerObject::update(dt);

        if (!m_fields->userHolding || !active()) return;

        auto cps = Mod::get()->getSettingValue<int64_t>("cps");
        float halfPeriod = 1.f / (2.f * static_cast<float>(cps));

        m_fields->timer += dt;
        if (m_fields->timer < halfPeriod) return;
        m_fields->timer -= halfPeriod;

        if (m_fields->spamDown) {
            PlayerObject::releaseButton(PlayerButton::Jump);
        } else {
            PlayerObject::pushButton(PlayerButton::Jump);
        }
        m_fields->spamDown = !m_fields->spamDown;
    }
};
